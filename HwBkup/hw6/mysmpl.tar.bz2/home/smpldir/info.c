#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <sys/utsname.h>
#include <stdlib.h>

int main(void)
{
   struct passwd *pw;
   struct utsname mysys;
   char hostname[256];

   pw = getpwuid(getuid());

   printf("*** Information about me.\n");
   printf("Name = %s, UID = %d, GID = %d, HOME = %s, SHELL = %s\n",
       pw->pw_name, pw->pw_uid, pw->pw_gid, pw->pw_dir, pw->pw_shell);

   if(gethostname(hostname,255)!=0) {
      perror("gethostname");
      exit(1);
   }

   printf("\n*** Information about the system.\n");
   printf("Hostname = %s\n", hostname);

   if(uname(&mysys)==-1) {
      perror("uname");
      exit(1);
   }

   printf("OS = %s\n", mysys.sysname);
   printf("Nodename = %s\n", mysys.nodename);
   printf("Release = %s\n", mysys.release);
   printf("Version = %s\n", mysys.version);
   printf("Hardware = %s\n", mysys.machine);

   return 0;
}

