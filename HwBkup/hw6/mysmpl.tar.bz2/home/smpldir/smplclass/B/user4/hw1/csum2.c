// This program computes the sum from 1 to n.
#include <stdio.h>

int main(void)
{
  int sum,i,n;

  printf("Enter a number.   ");
  scanf("%d",&n);

  sum=0;
  for (i=1; i<=n; i++)
    sum=sum+i;
  printf("The sum from 1 to %d is %d.\n",n,sum);
}
