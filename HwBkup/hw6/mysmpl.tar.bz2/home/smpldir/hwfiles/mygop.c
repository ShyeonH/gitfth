#include <stdio.h>

int mygop(int a, int b)
{
   return a * b;
}
