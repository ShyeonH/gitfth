#include <stdio.h>

int main(void)
{
   FILE *fp;
   char name[30];

   system("who | sort | cut -d ' ' -f 1 | uniq > UsersNow");

   fp=fopen("UsersNow","r");
   while (fscanf(fp,"%s",name)!=EOF) {
      printf("user %s\n",name);
   }
   fclose(fp);

}
