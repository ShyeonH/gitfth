#include <stdio.h>

int main(void)
{
   printf("This program calls the static library staticf.\n");
   staticf();

   return 0;
}
