#include <stdio.h>

void gongyoo(void)
{
   printf("My shared library function gongyoo called\n");
}
