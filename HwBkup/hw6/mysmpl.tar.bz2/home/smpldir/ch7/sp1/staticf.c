#include <stdio.h>

void staticf(void)
{
   printf("My static library function staticf called\n");
}
