#include <stdio.h>

int main(void)
{
   printf("This program calls the shared library gongyoo.\n");
   gongyoo();

   return 0;
}
