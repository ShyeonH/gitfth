void swap();            /* Define function prototype */
