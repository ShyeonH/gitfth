#include <stdio.h>

int main(void)
{
  int a,b;
  printf("Enter the first number.  ");
  scanf("%d",&a);
  printf("Enter the second number. ");
  scanf("%d",&b);
  printf("The sum is %d.\n",a+b);
}
