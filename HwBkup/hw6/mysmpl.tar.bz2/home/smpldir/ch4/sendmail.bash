mail $1 << ENDOFTXT
Dear $1,
How are you?
$USER
ENDOFTXT
echo Sent to $1
